
<div class="row">
<!-- [ bar-Chart ] start -->
<div class="col-xl-12">
    <div class="card">
        <div class="card-header">
            <h5>Member State KPIs</h5>
        </div>
        <div class="card-body">
            <div id="large_chart" style="width: 100%; height: 450px;"></div>
        </div>
    </div>
</div>

</div>

