<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rccs_mdl extends CI_Model
{


    public function __Construct()
    {

        parent::__Construct();
    }

    public function countries_data()
    {

    }

}
